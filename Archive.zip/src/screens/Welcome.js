import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

const Welcome = () => {
    return(
        <View>
            <Text>
                Welcome
            </Text>
        </View>
    );
}

export default Welcome;